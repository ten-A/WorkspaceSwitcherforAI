var csInterface = new CSInterface();
function init(){
	//alert("init panel...");
	csInterface.addEventListener("com.adobe.csxs.events.Switchworkspace", Switchworkspace);
	if (window.localStorage){
		if (localStorage.getItem('wsSwitcher')==undefined||localStorage.getItem('wsSwitcher')=="undefined") {
			localStorage.setItem('wsSwitcher', true);
			csInterface.evalScript('pref()');
			}
		}
	var menuXML  = '<Menu><MenuItem Id="menuItemId1" Label="preference" Enabled="true" Checked="false"/></Menu>';
	csInterface.setPanelFlyoutMenu(menuXML);
	csInterface.addEventListener("com.adobe.csxs.events.flyoutMenuClicked", setPanelCallback);
	csInterface.addEventListener("getPref", function(evt) {
		if (evt.data!=""){
			var wsn = evt.data.split(",");
			for (var i=0;i<wsn.length;i++) localStorage.setItem('wsSwitcher_wsn'+i, wsn[i]);
			}
		});

    function setPanelCallback() {
    	   var str = [];
    	   for (var i=0;i<9;i++) str.push(localStorage.getItem('wsSwitcher_wsn'+i));
        csInterface.evalScript("pref('" + str.join(',') + "')");
        }
	themeManager.init();
	}
aiwsName = "";




function Switchworkspace(ev) {
/*
workspace0 default workspace
workspace1 art work edit
workspace2 text edit
*/
//alert(ev.data);
     //alert($("input#registerEvent").prop("checked"));
	if (!document.getElementById("registerEvent").checked) return;
	var toolName = [];
	toolName["Adobe Type Tool"] = 2;
	toolName["Adobe Area Type Tool"] = 2;
	toolName["Adobe Path Type Tool"] = 2;
	toolName["Adobe Vertical Type Tool"] = 2;
	toolName["Adobe Vertical Area Type Tool"] = 2
	toolName["Adobe Vertical Path Type Tool"] = 2;
	toolName["Adobe Touch Type Tool"] = 2;

	toolName["Adobe Right-To-Left Type Tool"] = 2;
	toolName["Adobe Right-To-Left Area Type Tool"] = 2;
	toolName["Adobe Right-To-Left Path Type Tool"] = 2;

	toolName["Adobe Rectangle Tool"] = 3;
	toolName["Adobe Rounded Rectangle Tool"] = 3;
	toolName["Adobe Ellipse Tool"] = 3;

	toolName["Adobe Select Tool"] = 0;
	toolName["Adobe Toggle Select Tool"] = 0
	toolName["Adobe Direct Select Tool"] = 0;
	toolName["Adobe Toggle Direct Select Tool"] = 0;
	toolName["Adobe Direct Object Select Tool"] = 0;

	toolName["Adobe Scale Tool"] =5;
	toolName["Adobe Rotate Tool"] =5;
	toolName["Adobe Reflect Tool"] =5;
	toolName["Adobe Shear Tool"] =5;

	toolName["Adobe Column Graph Tool"] = 8;
	toolName["Adobe Stacked Column Graph Tool"] = 8;
	toolName["Adobe Line Graph Tool"] = 8;
	toolName["Adobe Pie Graph Tool"] = 8;
	toolName["Adobe Area Graph Tool"] = 8;
	toolName["Adobe Scatter Graph Tool"] = 8;
	toolName["Adobe Bar Graph Tool"] = 8;
	toolName["Adobe Stacked Bar Graph Tool"] = 8;
	toolName["Adobe Radar Graph Tool"] = 8;

	toolName["Adobe Scroll Tool"] = 6;
	toolName["Adobe Freehand Tool"] = 5;
	toolName["Adobe Freehand Smooth Tool"] = 5;
	toolName["Adobe Freehand Erase Tool"] = 5;
	toolName["Adobe Stencil Tool"] = 5;
	toolName["Adobe Corner Join Tool"] = 5;

	toolName["Adobe Pen Tool"] = 1;
	toolName["Adobe Blend Tool"] = 5;
	toolName["Adobe Scissors Tool"] = 6;
	toolName["Adobe Measure Tool"] = 6;
	toolName["Adobe Page Tool"] = 6;
	toolName["Adobe Zoom Tool"] = 6;
	toolName["Adobe Add Anchor Point Tool"] = 1;
	toolName["Adobe Delete Anchor Point Tool"] = 1;
	toolName["Adobe Anchor Point Tool"] = 1;
	toolName["Adobe Gradient Vector Tool"] = 4;
	toolName["Adobe Brush Tool"] = 4;
	toolName["Adobe Eyedropper Tool"] = 4;
	toolName["Adobe Reshape Tool"] = 5;
	toolName["Adobe Width Tool"] = 5;
	toolName["Adobe Knife Tool"] = 6;
	toolName["Adobe Shape Construction Regular Polygon Tool"] = 3;
	toolName["Adobe Shape Construction Star Tool"] = 3;
	toolName["Adobe Shape Construction Spiral Tool"] = 3;

	toolName["Adobe Mesh Editing Tool"] = 4;
	toolName["Adobe Free Transform Tool"] = 5;
	toolName["Adobe Direct Lasso Tool"] = 0;
	toolName["Adobe Ellipse Shape Tool"] = 3;
	toolName["Adobe Rectangle Shape Tool"] = 3;

	// New for AI10
	toolName["Adobe Magic Wand Tool"] = 0;

	toolName["Adobe Line Tool"] = 3;
	toolName["Adobe Arc Tool"] = 3;
	toolName["Adobe Rectangular Grid Tool"] = 3;
	toolName["Adobe Polar Grid Tool"] = 3;
	toolName["Adobe Flare Tool"] = 3;

	toolName["Adobe Warp Tool"] = 5;
	toolName["Adobe New Twirl Tool"] = 5;
	toolName["Adobe Pucker Tool"] = 5;
	toolName["Adobe Bloat Tool"] = 5;
	toolName["Adobe Scallop Tool"] = 5;
	toolName["Adobe Cyrstallize Tool"] = 5;
	toolName["Adobe Wrinkle Tool"] = 5;

	toolName["Adobe Slice Tool"] = 6;
	toolName["Adobe Slice Select Tool"] = 6;

	toolName["Adobe Symbol Sprayer Tool"] = 7;
	toolName["Adobe Symbol Shifter Tool"] = 7;
	toolName["Adobe Symbol Scruncher Tool"] = 7;
	toolName["Adobe Symbol Sizer Tool"] = 7;
	toolName["Adobe Symbol Spinner Tool"] = 7;
	toolName["Adobe Symbol Stainer Tool"] = 7;
	toolName["Adobe Symbol Screener Tool"] = 7;
	toolName["Adobe Symbol Styler Tool"] = 7;

	// New for AI12
	toolName["Adobe Planar Paintbucket Tool"] = 4;
	toolName["Adobe Planar Face Select Tool"] = 4;

	// New for AI13
	toolName["Adobe Eraser Tool"] = 6;
	toolName["Adobe Crop Tool"] = 6;

	// New for AI14
	toolName["Adobe Blob Brush Tool"] = 4;

	// New for AI15
	toolName["Adobe Shape Builder Tool"] = 3;
	toolName["Perspective Grid Tool"] = 6;
	toolName["Perspective Selection Tool"] = 6
	// New for AI16
	toolName["Adobe Pattern Tile Tool"] = 6;
	// New for AI17
	toolName["Adobe Place Gun Tool"] = 6;

	// New for AI18.1
	toolName["Adobe Curvature Tool"] = 1;


	//New for CC Charts
	toolName["CC Charts Tool"] = 8;

	//New for 19.0
	toolName["Adobe Shaper Tool"] = 5;

	//New for 19.3 (October release)
	toolName["Adobe Symmetry Tool"] = 5;
	
	var xmlData = $.parseXML(ev.data);
	var $xml = $(xmlData);
	var nm = $xml.find('toolname').text();
	if (aiwsName==toolName[nm]) return;
	aiwsName = toolName[nm];
	var csi = new CSInterface();
	//
	csi.evalScript('applyWorkspace("' + localStorage.getItem('wsSwitcher_wsn'+aiwsName) + '")');
    }


